// Cat Care Pro Landing Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all functionality
    initFAQ();
    initSalesCounter();
    initCTAButtons();
    initSmoothScrolling();
    initScrollAnimations();
    
    console.log('Cat Care Pro page loaded successfully!');
});

// Checkout URL
const CHECKOUT_URL = 'https://pay.hotmart.com/S100796519P';

// FAQ Toggle Functionality
function initFAQ() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all other FAQ items
            faqItems.forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('active');
                    otherItem.querySelector('.faq-answer').classList.remove('active');
                }
            });
            
            // Toggle current item
            if (isActive) {
                item.classList.remove('active');
                answer.classList.remove('active');
            } else {
                item.classList.add('active');
                answer.classList.add('active');
            }
        });
    });
}

// Dynamic Sales Counter
function initSalesCounter() {
    const counter = document.getElementById('vendas-counter');
    if (!counter) return;
    
    let currentCount = 127;
    const baseCount = 127;
    const maxIncrease = 15;
    
    // Update counter every 30-60 seconds
    setInterval(() => {
        const increase = Math.floor(Math.random() * 3) + 1; // 1-3 increase
        currentCount += increase;
        
        // Reset if it gets too high
        if (currentCount > baseCount + maxIncrease) {
            currentCount = baseCount + Math.floor(Math.random() * 5);
        }
        
        counter.textContent = currentCount;
        
        // Add pulse animation
        counter.parentElement.style.animation = 'pulse 0.5s ease-in-out';
        setTimeout(() => {
            counter.parentElement.style.animation = '';
        }, 500);
    }, Math.random() * 30000 + 30000); // 30-60 seconds
}

// CTA Button Handlers - Updated to redirect to checkout
function initCTAButtons() {
    // Get all CTA buttons with more specific selectors
    const ctaButtons = document.querySelectorAll('.cta-button, .btn--primary');
    
    console.log('Found CTA buttons:', ctaButtons.length);
    
    ctaButtons.forEach((button, index) => {
        console.log(`Attaching click handler to button ${index}:`, button.textContent);
        
        // Remove any existing event listeners
        button.removeEventListener('click', handleCTAClick);
        
        // Add the event listener
        button.addEventListener('click', function(e) {
            console.log('CTA button clicked:', this.textContent);
            handleCTAClick(e);
        });
    });
}

function handleCTAClick(e) {
    e.preventDefault();
    e.stopPropagation();
    
    console.log('handleCTAClick called');
    
    const button = e.target;
    const originalText = button.textContent;
    
    // Check if it's a purchase button (not navigation)
    if (button.textContent.includes('Comprar Agora') || 
        button.textContent.includes('Quero Proteger') || 
        button.textContent.includes('🛒') ||
        button.classList.contains('cta-button')) {
        
        console.log('Processing purchase button - redirecting to checkout');
        
        // Show loading state
        button.textContent = '⏳ Redirecionando...';
        button.disabled = true;
        
        // Add tracking (for analytics)
        if (typeof gtag !== 'undefined') {
            gtag('event', 'purchase_intent', {
                'event_category': 'ecommerce',
                'event_label': 'cat_care_pro',
                'value': 19.90
            });
        }
        
        // Redirect to checkout after short delay
        setTimeout(() => {
            console.log('Redirecting to:', CHECKOUT_URL);
            window.open(CHECKOUT_URL, '_blank');
            
            // Reset button
            button.textContent = originalText;
            button.disabled = false;
        }, 1000);
    } else {
        // For navigation buttons, just scroll to the target
        const href = button.getAttribute('href');
        if (href && href.startsWith('#')) {
            const targetId = href.substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const header = document.querySelector('.header');
                const headerHeight = header ? header.offsetHeight : 0;
                const targetPosition = targetElement.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        }
    }
}

// Smooth Scrolling - Fixed
function initSmoothScrolling() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    console.log('Found navigation links:', navLinks.length);
    
    navLinks.forEach((link, index) => {
        console.log(`Navigation link ${index}:`, link.getAttribute('href'));
        
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            const targetId = link.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            console.log('Scrolling to:', targetId, targetElement);
            
            if (targetElement) {
                const header = document.querySelector('.header');
                const headerHeight = header ? header.offsetHeight : 0;
                const targetPosition = targetElement.offsetTop - headerHeight - 20;
                
                console.log('Scrolling to position:', targetPosition);
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            } else {
                console.log('Target element not found:', targetId);
            }
        });
    });
}

// Scroll Animations
function initScrollAnimations() {
    // Check if IntersectionObserver is available
    if (!window.IntersectionObserver) {
        console.log('IntersectionObserver not supported');
        return;
    }
    
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'fadeInUp 0.6s ease-out forwards';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animateElements = document.querySelectorAll(
        '.benefit-card, .depoimento-card, .stat-card, .feature-item, .faq-item'
    );
    
    animateElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(20px)';
        observer.observe(element);
    });
    
    // Add animation styles
    const animationStyles = document.createElement('style');
    animationStyles.id = 'animation-styles';
    animationStyles.textContent = `
        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    `;
    
    // Remove existing animation styles
    const existingStyles = document.getElementById('animation-styles');
    if (existingStyles) {
        existingStyles.remove();
    }
    
    document.head.appendChild(animationStyles);
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Add scroll-based header behavior
window.addEventListener('scroll', debounce(() => {
    const header = document.querySelector('.header');
    if (header) {
        if (window.scrollY > 100) {
            header.style.background = 'linear-gradient(135deg, rgba(45, 139, 58, 0.95) 0%, rgba(76, 175, 80, 0.95) 100%)';
            header.style.backdropFilter = 'blur(10px)';
        } else {
            header.style.background = 'linear-gradient(135deg, var(--color-cat-green) 0%, var(--color-cat-green-light) 100%)';
            header.style.backdropFilter = 'none';
        }
    }
}, 100));

// Track user engagement
function trackEngagement() {
    const startTime = Date.now();
    
    // Track scroll depth
    let maxScroll = 0;
    window.addEventListener('scroll', () => {
        const scrollPercent = Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100);
        maxScroll = Math.max(maxScroll, scrollPercent);
    });
    
    // Track time on page
    window.addEventListener('beforeunload', () => {
        const timeSpent = Math.round((Date.now() - startTime) / 1000);
        console.log(`User spent ${timeSpent} seconds on page, max scroll: ${maxScroll}%`);
    });
}

// Initialize engagement tracking
trackEngagement();

// Add urgency and scarcity effects
function addUrgencyEffects() {
    const urgencyTexts = [
        "⚡ Últimas unidades!",
        "🔥 Oferta por tempo limitado!",
        "⏰ Apenas hoje com desconto!",
        "🎯 Vagas limitadas!"
    ];
    
    const urgencyElements = document.querySelectorAll('.urgency-counter p');
    if (urgencyElements.length > 0) {
        let currentTextIndex = 0;
        
        setInterval(() => {
            urgencyElements.forEach(element => {
                const currentText = element.innerHTML;
                const salesNumber = currentText.match(/\d+/);
                const newText = urgencyTexts[currentTextIndex];
                
                if (salesNumber) {
                    element.innerHTML = `${newText} ${salesNumber[0]} pessoas compraram hoje!`;
                }
            });
            
            currentTextIndex = (currentTextIndex + 1) % urgencyTexts.length;
        }, 5000);
    }
}

// Initialize urgency effects
addUrgencyEffects();

// Add exit intent detection
function addExitIntent() {
    let exitIntentShown = false;
    
    document.addEventListener('mouseleave', (e) => {
        if (!exitIntentShown && e.clientY <= 0) {
            exitIntentShown = true;
            showExitIntentPopup();
        }
    });
}

function showExitIntentPopup() {
    const popup = document.createElement('div');
    popup.className = 'exit-intent-popup';
    popup.innerHTML = `
        <div class="exit-popup-content">
            <div class="exit-popup-header">
                <h2>🚨 Espere!</h2>
                <button class="exit-close" type="button">&times;</button>
            </div>
            <div class="exit-popup-body">
                <p><strong>Não deixe seu gato desprotegido!</strong></p>
                <p>Leve o Cat Care Pro agora e tenha a tranquilidade de saber como agir em emergências.</p>
                <div class="exit-offer">
                    <span class="exit-price">Apenas R$ 19,90</span>
                    <span class="exit-guarantee">✅ Garantia de 30 dias</span>
                </div>
            </div>
            <div class="exit-popup-footer">
                <button class="btn btn--primary exit-cta" type="button">Sim, Quero Proteger Meu Gato!</button>
                <button class="btn btn--secondary exit-close" type="button">Talvez Depois</button>
            </div>
        </div>
    `;
    
    const popupStyles = document.createElement('style');
    popupStyles.id = 'exit-popup-styles';
    popupStyles.textContent = `
        .exit-intent-popup {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            animation: fadeIn 0.3s ease-in-out;
        }
        
        .exit-popup-content {
            background: white;
            border-radius: var(--radius-lg);
            max-width: 500px;
            width: 90%;
            animation: slideIn 0.3s ease-in-out;
            border: 3px solid var(--color-cat-green);
        }
        
        .exit-popup-header {
            padding: var(--space-24);
            border-bottom: 1px solid var(--color-border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--color-cat-bg-light);
        }
        
        .exit-popup-header h2 {
            color: var(--color-cat-green-dark);
            margin: 0;
        }
        
        .exit-close {
            background: none;
            border: none;
            font-size: var(--font-size-2xl);
            cursor: pointer;
            color: var(--color-text-secondary);
            padding: var(--space-4);
            line-height: 1;
        }
        
        .exit-popup-body {
            padding: var(--space-24);
            text-align: center;
        }
        
        .exit-offer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: var(--space-16);
            padding: var(--space-16);
            background: var(--color-cat-bg-light);
            border-radius: var(--radius-base);
        }
        
        .exit-price {
            font-size: var(--font-size-xl);
            font-weight: var(--font-weight-bold);
            color: var(--color-cat-green);
        }
        
        .exit-guarantee {
            color: var(--color-cat-green);
            font-weight: var(--font-weight-medium);
        }
        
        .exit-popup-footer {
            padding: var(--space-24);
            display: flex;
            gap: var(--space-12);
            flex-direction: column;
        }
        
        .exit-cta {
            background: linear-gradient(135deg, var(--color-cat-green), var(--color-cat-green-light)) !important;
            color: white !important;
            font-weight: var(--font-weight-bold) !important;
        }
        
        .exit-cta:hover {
            background: linear-gradient(135deg, var(--color-cat-green-dark), var(--color-cat-green)) !important;
        }
    `;
    
    document.head.appendChild(popupStyles);
    document.body.appendChild(popup);
    
    // Close functionality
    const closeButtons = popup.querySelectorAll('.exit-close');
    closeButtons.forEach(button => {
        button.addEventListener('click', () => {
            popup.remove();
            popupStyles.remove();
        });
    });
    
    // Purchase button
    const purchaseButton = popup.querySelector('.exit-cta');
    purchaseButton.addEventListener('click', () => {
        popup.remove();
        popupStyles.remove();
        
        // Redirect to checkout
        window.open(CHECKOUT_URL, '_blank');
    });
}

// Initialize exit intent (only on desktop)
if (window.innerWidth > 768) {
    addExitIntent();
}

// Add some fun interactions
function addEasterEggs() {
    let catClickCount = 0;
    const catEmojis = document.querySelectorAll('.header__logo');
    
    catEmojis.forEach(emoji => {
        emoji.addEventListener('click', () => {
            catClickCount++;
            if (catClickCount === 5) {
                showCatAnimation();
                catClickCount = 0;
            }
        });
    });
}

function showCatAnimation() {
    const cats = ['🐱', '😸', '😺', '😻', '🙀', '😿', '😾'];
    const container = document.createElement('div');
    container.style.position = 'fixed';
    container.style.top = '0';
    container.style.left = '0';
    container.style.width = '100%';
    container.style.height = '100%';
    container.style.pointerEvents = 'none';
    container.style.zIndex = '9999';
    
    for (let i = 0; i < 20; i++) {
        const cat = document.createElement('div');
        cat.textContent = cats[Math.floor(Math.random() * cats.length)];
        cat.style.position = 'absolute';
        cat.style.fontSize = '30px';
        cat.style.left = Math.random() * 100 + '%';
        cat.style.top = Math.random() * 100 + '%';
        cat.style.animation = `catFall ${Math.random() * 3 + 2}s linear forwards`;
        container.appendChild(cat);
    }
    
    const catStyles = document.createElement('style');
    catStyles.id = 'cat-animation-styles';
    catStyles.textContent = `
        @keyframes catFall {
            0% { transform: translateY(-50px) rotate(0deg); opacity: 1; }
            100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
        }
    `;
    
    document.head.appendChild(catStyles);
    document.body.appendChild(container);
    
    setTimeout(() => {
        container.remove();
        catStyles.remove();
    }, 5000);
}

// Initialize easter eggs
addEasterEggs();

// Performance monitoring
function monitorPerformance() {
    if ('performance' in window) {
        window.addEventListener('load', () => {
            const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
            console.log(`Page loaded in ${loadTime}ms`);
        });
    }
}

// Initialize performance monitoring
monitorPerformance();

// Additional debugging
console.log('JavaScript loaded and ready - Checkout URL:', CHECKOUT_URL);